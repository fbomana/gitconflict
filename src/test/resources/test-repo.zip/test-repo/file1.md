#Test File 1

This is a simple test file.

#Merged changed

This changed is merged in master so this branch shoud not generate conflicts.